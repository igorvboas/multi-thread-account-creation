
        var config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "156.253.176.168",
                    port: parseInt(3129)
                },
                bypassList: ["localhost"]
            }
        };
        chrome.proxy.settings.set({value: config, scope: "regular"}, function(){});
        chrome.webRequest.onAuthRequired.addListener(
            function(details) {
                return {
                    authCredentials: {
                        username: "lzrldpsg",
                        password: "0uw6l6wk2bp8"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ['blocking']
        );
        